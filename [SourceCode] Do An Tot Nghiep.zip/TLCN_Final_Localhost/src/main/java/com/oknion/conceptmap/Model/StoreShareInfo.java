package com.oknion.conceptmap.Model;


public class StoreShareInfo {

	private double cmId;
	private boolean checkme;
	private String listUsername;

	public double getCmId() {
		return cmId;
	}

	public void setCmId(double cmId) {
		this.cmId = cmId;
	}

	public boolean isCheckme() {
		return checkme;
	}

	public void setCheckme(boolean checkme) {
		this.checkme = checkme;
	}

	public String getListUsername() {
		return listUsername;
	}

	public void setListUsername(String listUsername) {
		this.listUsername = listUsername;
	}

}
