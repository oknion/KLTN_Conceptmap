package com.oknion.conceptmap.utils;

public enum Role {
	ROLE_USER, ROLE_STUDENT, ROLE_ADMIN
}
