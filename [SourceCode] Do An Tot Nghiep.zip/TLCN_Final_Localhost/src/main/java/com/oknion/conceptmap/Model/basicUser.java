package com.oknion.conceptmap.Model;

public class basicUser {
	public String username;
	public String fullName;
	public String mssv;
	public String email;

	public basicUser(String username, String fullName, String mssv, String email) {
		this.username = username;
		this.fullName = fullName;
		this.mssv = mssv;
		this.email = email;
	}
}
