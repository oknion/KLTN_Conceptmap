package com.oknion.conceptmap.utils;

public enum SocialMediaService {
	FACEBOOK
}
